# Proyecto XGBoost — Regresión de `ti_2d`

Pipeline end-to-end para predecir un valor monetario (`ti_2d`) con
XGBoost, comparando dos loss functions, con tuning automático vía
Optuna y tracking en MLflow.

**Diseñado para flujo interactivo en JupyterLab**: ejecutas el
notebook chunk por chunk y vas viendo progreso, métricas y
visualizaciones (histogramas, barplots de gain, heatmaps de matriz
de rangos, scatter pred vs real).

---

## Estructura

```
proyecto_xgb_reg/
├── data/                    # CSVs de entrada (train.csv, test.csv)
├── notebooks/
│   ├── 00_pipeline.ipynb    # ⭐ notebook interactivo principal
│   ├── mlruns/              # tracking MLflow (autocreado)
│   └── *.json, *.pkl        # artefactos generados (modelos, rankings, preprocessor)
├── src/                     # código fuente reutilizable
│   ├── config.py            # ⭐ TODA la configuración centralizada
│   ├── data.py
│   ├── preprocessing.py
│   ├── selection.py
│   ├── features.py
│   ├── evaluate.py
│   ├── tune.py
│   ├── train.py
│   ├── predict.py
│   ├── pipeline.py          # orquestador alterno (CLI, no notebook)
│   ├── tracking.py
│   └── utils.py
├── requirements.txt
├── environment.yml          # conda GPU
├── environment_cpu.yml      # conda CPU fallback
├── Makefile
├── .gitignore
└── README.md
```

---

## Flujo recomendado (Jupyter)

### 1. Instalar dependencias

```bash
# GPU (servidor Azure con CUDA 12.x)
conda env create -f environment.yml
conda activate xgb_reg_gpu

# o CPU (laptop local)
conda env create -f environment_cpu.yml
conda activate xgb_reg_cpu
```

### 2. Colocar los CSVs

```bash
cp ruta/a/train.csv data/
cp ruta/a/test.csv  data/
```

Si los nombres de target/ID difieren, ajustar en `src/config.py`:

```python
TARGET_COL = "ti_2d"
ID_COL = "id"
CATEGORICAL_COLS = []   # opcional: ["tipo_cliente", "segmento", ...]
```

### 3. Lanzar JupyterLab

```bash
make jupyter
# equivalente a: cd notebooks && jupyter lab
```

Abre `00_pipeline.ipynb` y ejecuta celda por celda. El notebook está
estructurado en 14 secciones:

| # | Sección | Qué verás |
|---|---|---|
| 1 | Setup | Versiones, GPU, config |
| 2 | Cargar datos | Shapes y head |
| 3 | EDA target | Histograma original + log1p, distribución por bins |
| 4 | Preprocesamiento | Imputaciones, tipos |
| 5 | Ranking inicial | Tabla + barplot top-30 (rojo = entra a FE) |
| 6 | Feature engineering | Conteos de features generadas |
| 7 | Re-ranking final | Barplot azul/naranja (original/generada) + composición por familia |
| 8 | Tuning Optuna | Loss A y Loss B, optimization history |
| 9 | Fit final | Modelos con best params |
| 10 | Predicciones | Rangos de predicción |
| 11 | Métricas | Tablas comparativas: globales, extremos, diagonal, por decil |
| 12 | Visualizaciones | Scatter pred vs real, heatmap matriz rangos, RMSE/MAE por decil |
| 13 | Loggear MLflow | Parent run + child runs por loss + ganador |
| 14 | Listing final | Inventario de artefactos generados |

### 4. Ver MLflow

En otra terminal:

```bash
make mlflow-ui
# equivalente a: cd notebooks && mlflow ui --port 5000
```

Y abre <http://localhost:5000>. Si estás en Azure, túnel SSH:

```bash
ssh -L 5000:localhost:5000 usuario@servidor-azure
```

---

## Flujo alternativo (CLI)

Si prefieres correr todo de un jalón sin notebook:

```bash
make run
# equivalente a: python -m src.pipeline
```

El pipeline CLI hace exactamente lo mismo que el notebook pero sin
visualizaciones intermedias. Útil para scripts o cron jobs.

---

## Inferencia en producción

```bash
python -m src.predict \
    --input data/nuevos_datos.csv \
    --model notebooks/xgb_B_squared_signedlog1p.json \
    --output notebooks/predicciones.csv
```

El script:

1. Carga `preprocessor.pkl` y reconstruye el pipeline de imputación.
2. Regenera automáticamente las features combinatoriales.
3. Predice e invierte la transformación del target si la loss lo requiere.
4. Escribe CSV con `id,y_pred`.

---

## Decisiones técnicas

### Las 2 loss functions comparadas

| ID | `xgb_objective` | Target transform | Por qué |
|---|---|---|---|
| **A** | `reg:pseudohubererror` | ninguna | Robusta a outliers en ambas colas; admite negativos; controlada por `huber_slope`. |
| **B** | `reg:squarederror` | `sign(y)·log1p(|y|)` | Comprime colas pesadas preservando signo; invertible; suele capturar extremos sin sacrificar la masa. |

Se descartaron `reg:tweedie`, `reg:squaredlogerror` y log directo
porque exigen target ≥ 0 (el ~3% de `ti_2d` es negativo).

### Métricas registradas (todas en MLflow)

- **Globales:** RMSE, MAE, MedAE, R², explained_variance, Pearson, Spearman, SMAPE.
- **Por decil del real:** RMSE, MAE, MedAE.
- **Extremos (P≤2 y P≥98):** RMSE, MAE, MedAE, Spearman, recall de extremos.
- **Matriz de rangos:** crosstab real × pred con bins de negocio (`<0`, `0-1k`, `1k-3k`, ..., `200k-500k`, `>500k`) y % en diagonal exacta, ±1, ±2, ±3.

### Selección de variables

- Único criterio: **gain** de XGBoost.
- Dos pasadas: ranking inicial sobre originales (define top-k) y ranking final sobre originales + generadas.
- Selección final: features con `gain > 0` en el ranking final.

### Tuning

- **Optuna TPE multivariate + MedianPruner** (startup=8, warmup=15).
- **XGBoost early_stopping_rounds=50** + pruning callback.
- Métrica optimizada: **RMSE en escala original del target** (las dos
  losses se comparan en la misma escala, no en la transformada).

### Reproducibilidad

- Semilla global `RANDOM_SEED = 42`.
- Split val interno fijo durante tuning.
- Preprocessor serializado con `joblib`.
- Modelo en JSON nativo XGBoost + sidecar `.meta.json` con best_params, features, métricas y fecha.

---

## Cambiar de GPU a CPU

Un solo switch en `src/config.py`:

```python
USE_GPU = False
```

Automáticamente:

- `DEVICE = "cpu"` en todos los XGBoost.
- Submuestreo estratificado por deciles del target (`SUBSAMPLE_ROWS_IF_CPU = 150_000`).

Para iterar más rápido en laptop, bajar también:

```python
TUNING_TIMEOUT_SEC_PER_LOSS = 300   # 5 min por loss
TUNING_N_TRIALS_MAX = 30
```

---

## Troubleshooting

### "CUDA out of memory"

```python
# config.py
USE_GPU = False
SUBSAMPLE_ROWS_IF_CPU = 300_000
```

### Falta `optuna-integration` para el pruning callback

```bash
pip install optuna-integration
```

### MLflow UI no muestra runs

Asegurarte de lanzarlo desde `notebooks/`:

```bash
cd notebooks && mlflow ui --port 5000
```

(Si lo lanzas desde la raíz, busca `./mlruns/` que está vacío.)

### Pipeline tarda más de 1.5h

```python
# config.py
TUNING_TIMEOUT_SEC_PER_LOSS = 900   # 15 min por loss
TUNING_N_TRIALS_MAX = 60
```

O dejar solo una loss:

```python
LOSS_CONFIGS = {
    "B_squared_signedlog1p": { ... },   # comentar la otra
}
```

---

## Artefactos generados (en `notebooks/`)

Después de correr el pipeline completo:

```
notebooks/
├── 00_pipeline.ipynb
├── mlruns/                                       # MLflow tracking
├── preprocessor.pkl                              # imputers + cats
├── feature_ranking_initial.json                  # ⭐ ranking sobre originales
├── feature_ranking_final.json                    # ⭐ ranking sobre originales + generadas
├── feature_list.json                             # lista plana de features finales
├── xgb_A_pseudohuber_raw.json                    # modelo A serializado
├── xgb_A_pseudohuber_raw.meta.json               # metadata + best params A
├── features_A_pseudohuber_raw.json
├── xgb_B_squared_signedlog1p.json                # modelo B serializado
├── xgb_B_squared_signedlog1p.meta.json
└── features_B_squared_signedlog1p.json
```

Los rankings en JSON tienen estructura:

```json
{
  "metadata": {
    "stage": "final_ranking_on_originals_plus_generated",
    "n_features_evaluated": 830,
    "n_features_with_gain_gt_0": 87,
    "n_originals": 200,
    "n_generated": 630,
    "top_k_used_for_fe": 20
  },
  "ranking": [
    {
      "rank": 1,
      "feature": "prod__balance_max__trx_count_12m",
      "gain": 3456.7,
      "kind": "generated",
      "family": "products",
      "base_vars": ["balance_max", "trx_count_12m"],
      "selected_in_final_model": true
    },
    ...
  ]
}
```
