# Proyecto XGBoost — Regresión de `ti_2d`

Pipeline end-to-end para predecir un valor monetario (`ti_2d`) con
XGBoost, comparando dos loss functions, con tuning automático vía
Optuna y tracking completo en MLflow.

## Tabla de contenidos

1. [Requisitos](#requisitos)
2. [Instalación](#instalación)
3. [Datos de entrada](#datos-de-entrada)
4. [Cómo correr el pipeline](#cómo-correr-el-pipeline)
5. [Visualizar MLflow](#visualizar-mlflow)
6. [Inferencia en producción](#inferencia-en-producción)
7. [Estructura del proyecto](#estructura-del-proyecto)
8. [Decisiones técnicas](#decisiones-técnicas)
9. [Qué cambiar si pierdes acceso al servidor con GPU](#qué-cambiar-si-pierdes-acceso-al-servidor-con-gpu)
10. [Troubleshooting](#troubleshooting)

---

## Requisitos

- **Python 3.11** (recomendado vía conda).
- **GPU con CUDA 12.x** para máxima velocidad (opcional; CPU también
  funciona con submuestreo).
- **~4-8 GB RAM** en CPU para submuestras; **~32+ GB RAM** para el
  dataset completo en CPU.
- **XGBoost 2.0+** (API unificada `device="cuda"|"cpu"`).

Verificar GPU en el servidor Azure:

```bash
nvidia-smi
```

---

## Instalación

### Con GPU (servidor Azure)

```bash
conda env create -f environment.yml
conda activate xgb_reg_gpu
```

### Sin GPU (laptop local)

```bash
conda env create -f environment_cpu.yml
conda activate xgb_reg_cpu
```

Verifica que XGBoost detecta la GPU:

```bash
python -c "import xgboost as xgb; print(xgb.__version__); \
    import xgboost; xgboost.XGBRegressor(device='cuda').get_params()"
```

---

## Datos de entrada

Coloca los CSVs en `data/raw/`:

```
data/raw/
├── train.csv     # ~500k filas × ~200 features + id + target
└── test.csv      # ~500k filas
```

Ajusta en `src/config.py` si los nombres de columnas difieren:

```python
TARGET_COL = "ti_2d"
ID_COL = "id"
CATEGORICAL_COLS = []   # opcional: ["tipo_cliente", "segmento", ...]
```

---

## Cómo correr el pipeline

### Opción A — Script Python (recomendado)

```bash
python -m src.pipeline
```

El pipeline:

1. Carga `train.csv` y `test.csv`.
2. Imputa missings (mediana/moda) y convierte categóricas a
   `pd.Categorical`.
3. Entrena XGBoost baseline → **ranking por gain** sobre features
   originales.
4. Toma el **top-k** (default `k=20`, ajustable en `config.TOP_K_FEATURES`)
   y genera features combinatoriales: productos, ratios protegidos,
   diferencias, cuadrados, signed-sqrt, signed-log1p.
5. **Re-ranking por gain** sobre (originales + generadas); se queda
   con todas las que tienen gain > 0.
6. Para cada loss en `config.LOSS_CONFIGS`:
   - Tuning con Optuna TPE + MedianPruner (presupuesto de tiempo).
   - Fit final con mejores params.
   - Evaluación completa en test.
   - Logging en MLflow como child run.
7. Declara ganador (mínimo `test_rmse`) y guarda resumen en el
   parent run.

### Opción B — Notebook interactivo

```bash
jupyter lab
# abrir notebooks/00_pipeline_end_to_end.ipynb
```

Incluye EDA rápido y visualización de la matriz de rangos del modelo
ganador.

### Presupuesto de tiempo por default (GPU)

| Etapa | Tiempo aprox |
|---|---|
| Carga + preprocess | 3-5 min |
| Ranking inicial por gain | 3-5 min |
| Feature engineering | 5-10 min |
| Re-ranking por gain | 3-5 min |
| Tuning loss A (Pseudo-Huber) | ~25 min (60-100 trials) |
| Tuning loss B (squared + log1p) | ~25 min |
| Evaluación + logging | 5 min |
| **Total** | **~75-80 min** |

Controlable vía `config.TUNING_TIMEOUT_SEC_PER_LOSS` y
`config.TUNING_N_TRIALS_MAX`.

---

## Visualizar MLflow

En el mismo servidor donde corriste el pipeline:

```bash
mlflow ui --backend-store-uri ./mlruns --port 5000
```

Abre <http://localhost:5000>.

Si estás en Azure, abre un túnel SSH desde tu laptop:

```bash
ssh -L 5000:localhost:5000 usuario@servidor-azure
```

Y luego abre <http://localhost:5000> en el navegador local.

Qué vas a ver:

- **Parent run** (`pipeline_YYYYMMDD_HHMMSS`) con tag `winner_loss`.
- **Child runs** por cada loss (`loss_A_pseudohuber_raw`,
  `loss_B_squared_signedlog1p`) con:
  - Parámetros: todos los de XGBoost + `xgb_objective`,
    `target_transform`, `loss_config_name`.
  - Métricas: `test_rmse`, `test_mae`, `test_medae`, `test_r2`,
    `test_pearson`, `test_spearman`, `test_smape_pct`,
    `test_ext_*` (extremos), `test_diag_exact|pm1|pm2|pm3`,
    `test_decile_low|high_rmse|mae`.
  - Artefactos: modelo `.json`, `preprocessor.pkl`,
    `feature_list.json`, `metrics_by_decile.csv`,
    `range_confusion_counts.csv`, `range_confusion_row_pct.csv`.

---

## Inferencia en producción

Con modelo entrenado:

```bash
python -m src.predict \
    --input data/raw/nuevos_datos.csv \
    --model models/xgb_B_squared_signedlog1p.json \
    --output reports/predicciones.csv
```

El script:

1. Carga `preprocessor.pkl` y reconstruye el pipeline de imputación.
2. Regenera automáticamente las features combinatoriales necesarias
   (derivado de los nombres en `features_*.json`).
3. Predice e **invierte la transformación del target** si la loss lo
   requiere.
4. Escribe CSV con `id,y_pred`.

---

## Estructura del proyecto

```
proyecto_xgb_reg/
├── data/
│   ├── raw/                 # CSVs originales (no versionar)
│   ├── interim/             # intermedios
│   └── processed/           # matrices finales
├── models/
│   ├── xgb_A_pseudohuber_raw.json          # modelo serializado
│   ├── xgb_A_pseudohuber_raw.meta.json     # sidecar con best_params
│   ├── xgb_B_squared_signedlog1p.json
│   ├── xgb_B_squared_signedlog1p.meta.json
│   ├── preprocessor.pkl                    # imputers + cats
│   ├── feature_list.json                   # features finales
│   └── features_<loss>.json                # por loss
├── notebooks/
│   └── 00_pipeline_end_to_end.ipynb
├── src/
│   ├── config.py            # TODA la config centralizada
│   ├── utils.py             # logger, seeds, io
│   ├── data.py              # carga CSV, tipos, submuestreo
│   ├── preprocessing.py     # Preprocessor + transforms target
│   ├── selection.py         # ranking por gain
│   ├── features.py          # FE combinatorial
│   ├── evaluate.py          # TODAS las métricas + matriz rangos
│   ├── tracking.py          # MLflow helpers
│   ├── tune.py              # Optuna TPE + MedianPruner
│   ├── train.py             # fit final + save JSON
│   ├── predict.py           # CLI inferencia
│   └── pipeline.py          # orquestador end-to-end
├── reports/figures/
├── mlruns/                  # MLflow local tracking
├── requirements.txt
├── environment.yml          # conda GPU
├── environment_cpu.yml      # conda CPU
├── Makefile                 # atajos comunes
├── .gitignore
└── README.md
```

---

## Decisiones técnicas

### Las 2 loss functions comparadas

| ID | `xgb_objective` | Target transform | Por qué |
|---|---|---|---|
| **A** | `reg:pseudohubererror` | ninguna | Robusta a outliers en ambas colas; no requiere target ≥ 0; controlada por `huber_slope`. |
| **B** | `reg:squarederror` | `sign(y)·log1p(|y|)` | Comprime colas pesadas preservando signo; invertible; suele capturar extremos sin sacrificar la masa en distribuciones muy sesgadas. |

Se descartaron:

- `reg:tweedie` y `reg:squaredlogerror`: exigen target ≥ 0, pero
  `ti_2d` tiene ~3% de valores negativos (hasta -228k).
- Log directo: no funciona con negativos.
- Winsorización del target: el usuario confirmó mantener todos los
  valores como pérdidas reales.

### Métricas registradas

**Globales:** RMSE, MAE, MedAE, R², explained_variance, Pearson,
Spearman, SMAPE (robusta a ceros).

**Por decil del target real:** RMSE, MAE, MedAE.

**Extremos (`y ≤ P2` y `y ≥ P98`):** RMSE, MAE, MedAE, Spearman y
**recall de extremos** (de los que realmente son extremos, qué % el
modelo los pone también en el extremo predicho).

**Matriz de rangos:** crosstab `real × pred` con los bins de negocio
(`0-1k`, `1k-3k`, ..., `200k-500k`, más `<0` y `>500k`) y porcentaje
en diagonal exacta, ±1, ±2, ±3.

### Selección de variables

- Único criterio: **gain de XGBoost** (según preferencia explícita).
- Dos pasadas: sobre originales (define top-k) y sobre originales +
  generadas (selección final).

### Tuning

- **Optuna TPE multivariate + MedianPruner** (startup=8, warmup=15).
- **XGBoost early_stopping_rounds=50** + pruning callback en
  `validation_0-rmse`.
- La métrica optimizada es **RMSE en escala original del target**
  (no en la escala transformada), para que las dos losses sean
  directamente comparables.

### Reproducibilidad

- Semilla global en `config.RANDOM_SEED = 42`.
- Split de validación interna fijo dentro del tuning.
- Preprocessor serializado con `joblib`.
- Modelo en formato nativo JSON de XGBoost + sidecar `.meta.json`
  con `best_params`, features, métricas y fecha.

---

## Qué cambiar si pierdes acceso al servidor con GPU

Un **único switch**:

```python
# src/config.py
USE_GPU = False
```

Automáticamente:

- `DEVICE = "cpu"` en todos los XGBRegressor.
- Submuestreo estratificado por deciles del target
  (`SUBSAMPLE_ROWS_IF_CPU = 150_000`) para que el fit termine en
  minutos en lugar de horas.

Para iterar aún más rápido en laptop, bajar también:

```python
TUNING_TIMEOUT_SEC_PER_LOSS = 300   # 5 min por loss
TUNING_N_TRIALS_MAX = 30
```

---

## Troubleshooting

### "CUDA out of memory"

Bajar `subsample` en `XGB_PARAM_SPACE` o reducir el dataset:

```python
# config.py
SUBSAMPLE_ROWS_IF_CPU = 300_000   # se usa solo si USE_GPU=False
```

O en GPU, temporalmente:

```python
# forzar CPU para diagnóstico
USE_GPU = False
```

### "XGBoostPruningCallback no disponible"

Instalar el paquete de integración:

```bash
pip install optuna-integration
```

### MLflow no muestra nada

Verificar que `./mlruns/` se creó y tiene permisos:

```bash
ls -la mlruns/
```

Borrar y re-correr:

```bash
rm -rf mlruns/
python -m src.pipeline
```

### Nombres de columnas distintos a lo esperado

Editar `src/config.py`:

```python
TARGET_COL = "mi_nombre_de_target"
ID_COL = "mi_id"
```

### El pipeline tardó más de 1.5h

Reducir presupuesto:

```python
# config.py
TUNING_TIMEOUT_SEC_PER_LOSS = 900   # 15 min por loss
TUNING_N_TRIALS_MAX = 60
```

O dejar solo una loss (la que quieras probar primero):

```python
LOSS_CONFIGS = {
    "B_squared_signedlog1p": { ... },   # comentar la otra
}
```

---

## Contacto / soporte

Revisar logs en stdout (formato `YYYY-MM-DD HH:MM:SS | módulo |
NIVEL | mensaje`). Todo artefacto relevante queda en `mlruns/` y
`models/`.
