"""Wrappers sobre MLflow para simplificar el tracking.

Centraliza:
    - Inicialización de tracking URI y experimento.
    - Logging de configuración (params, tags) y métricas planas.
    - Logging de artefactos (tablas, matrices, modelo JSON).
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import mlflow
import pandas as pd

from . import config as cfg
from .utils import setup_logger

logger = setup_logger(__name__)


def init_mlflow(
    tracking_uri: str = cfg.MLFLOW_TRACKING_URI,
    experiment_name: str = cfg.MLFLOW_EXPERIMENT_NAME,
) -> None:
    """Inicializa tracking URI y experimento.

    Args:
        tracking_uri: URI (default local ``file://.../mlruns``).
        experiment_name: Nombre del experimento a crear o usar.
    """
    mlflow.set_tracking_uri(tracking_uri)
    mlflow.set_experiment(experiment_name)
    logger.info(f"MLflow URI:        {tracking_uri}")
    logger.info(f"MLflow experiment: {experiment_name}")


def log_config_snapshot(extra: dict[str, Any] | None = None) -> None:
    """Loggea la configuración relevante como params + tags.

    Args:
        extra: Campos adicionales específicos del run.
    """
    params = {
        "use_gpu": cfg.USE_GPU,
        "device": cfg.DEVICE,
        "random_seed": cfg.RANDOM_SEED,
        "n_folds": cfg.N_FOLDS,
        "top_k_features": cfg.TOP_K_FEATURES,
        "extreme_lower_q": cfg.EXTREME_LOWER_Q,
        "extreme_upper_q": cfg.EXTREME_UPPER_Q,
        "tuning_timeout_sec": cfg.TUNING_TIMEOUT_SEC_PER_LOSS,
        "tuning_n_trials_max": cfg.TUNING_N_TRIALS_MAX,
    }
    if extra:
        params.update(extra)
    mlflow.log_params(params)


def log_metrics(metrics: dict[str, float]) -> None:
    """Loggea un dict plano de métricas."""
    # MLflow solo acepta floats/ints; filtramos NaNs
    clean = {}
    for k, v in metrics.items():
        try:
            fv = float(v)
            if fv == fv:  # descartar NaN
                clean[k] = fv
        except (TypeError, ValueError):
            continue
    if clean:
        mlflow.log_metrics(clean)


def log_dataframe_csv(df: pd.DataFrame, artifact_name: str) -> None:
    """Guarda un DataFrame como CSV en los artefactos del run."""
    tmp = Path("/tmp") / artifact_name
    tmp.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(tmp, index=True)
    mlflow.log_artifact(str(tmp))
    tmp.unlink(missing_ok=True)


def log_model_json(model_path: Path, artifact_subdir: str = "model") -> None:
    """Sube el modelo JSON como artefacto del run."""
    mlflow.log_artifact(str(model_path), artifact_path=artifact_subdir)
