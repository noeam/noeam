"""Orquestador end-to-end del pipeline.

Ejecuta en orden:

    1. Carga train/test desde CSV.
    2. Preprocesamiento (imputaciones, cats, submuestreo CPU).
    3. Ranking inicial por gain sobre features originales.
    4. Feature engineering combinatorial sobre top-k.
    5. Ranking final por gain; selección de variables definitivas.
    6. Tuning con Optuna para cada loss de :data:`config.LOSS_CONFIGS`.
    7. Entrenamiento final del modelo ganador (por loss).
    8. Evaluación completa en test.
    9. Logging en MLflow y persistencia del mejor modelo.

El pipeline crea un **run por loss** y un **run padre** con el resumen
comparativo.
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any

import mlflow
import numpy as np
import pandas as pd

from . import config as cfg
from .data import (
    infer_column_types,
    load_raw_csv,
    maybe_subsample,
    split_features_target,
)
from .evaluate import (
    flatten_metrics_for_mlflow,
    full_evaluation,
)
from .features import combine_features, generate_combinatorial_features
from .preprocessing import Preprocessor
from .selection import rank_by_gain, top_k_features
from .tracking import (
    init_mlflow,
    log_config_snapshot,
    log_dataframe_csv,
    log_metrics,
    log_model_json,
)
from .train import predict_original_scale, save_model_json, train_final_model
from .tune import run_study
from .utils import save_json, set_global_seed, setup_logger

logger = setup_logger(__name__)


# =============================================================================
# Etapas aisladas (fáciles de testear por separado)
# =============================================================================


def stage_load_and_preprocess(
    train_path: Path = cfg.TRAIN_FILE,
    test_path: Path = cfg.TEST_FILE,
) -> tuple[pd.DataFrame, pd.Series, pd.DataFrame, pd.Series, Preprocessor]:
    """Carga, infiere tipos, preprocesa, opcionalmente submuestrea.

    Returns:
        ``(X_train, y_train, X_test, y_test, preprocessor)``.
    """
    df_train = load_raw_csv(train_path)
    df_test = load_raw_csv(test_path)

    df_train = maybe_subsample(df_train)

    numeric_cols, categorical_cols = infer_column_types(
        df_train, known_categorical=cfg.CATEGORICAL_COLS
    )

    X_train, y_train, _ = split_features_target(df_train)
    X_test, y_test, _ = split_features_target(df_test)

    preprocessor = Preprocessor(
        numeric_cols=numeric_cols, categorical_cols=categorical_cols
    )
    X_train_pp = preprocessor.fit_transform(X_train)
    X_test_pp = preprocessor.transform(X_test)

    return X_train_pp, y_train, X_test_pp, y_test, preprocessor


def stage_feature_engineering(
    X_train: pd.DataFrame,
    y_train: pd.Series,
    X_test: pd.DataFrame,
    top_k: int = cfg.TOP_K_FEATURES,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, list[str]]:
    """Ranking inicial -> FE combinatorial -> ranking final.

    Returns:
        ``(X_train_fe, X_test_fe, df_rank_final, selected_features)``.
    """
    logger.info(">>> Etapa: ranking inicial por gain")
    df_rank_init = rank_by_gain(X_train, y_train)

    top = top_k_features(df_rank_init, top_k)
    logger.info(f">>> Top-{top_k}: {top}")

    logger.info(">>> Etapa: feature engineering combinatorial")
    X_new_train = generate_combinatorial_features(X_train, top)
    X_new_test = generate_combinatorial_features(X_test, top)

    X_train_full = combine_features(X_train, X_new_train)
    X_test_full = combine_features(X_test, X_new_test)

    logger.info(">>> Etapa: ranking final por gain (originales + generadas)")
    df_rank_final = rank_by_gain(X_train_full, y_train)

    # Regla de selección: todas las que tengan gain > 0 en el ranking final.
    # Ajustable si se quiere un cap fijo.
    selected = df_rank_final.loc[df_rank_final["gain"] > 0, "feature"].tolist()
    logger.info(f">>> Features finales seleccionadas: {len(selected)}")

    X_train_sel = X_train_full[selected]
    X_test_sel = X_test_full[selected]
    return X_train_sel, X_test_sel, df_rank_final, selected


def stage_tune_and_evaluate_one_loss(
    loss_config_name: str,
    X_train: pd.DataFrame,
    y_train: pd.Series,
    X_test: pd.DataFrame,
    y_test: pd.Series,
    parent_run_id: str,
    selected_features: list[str],
) -> dict[str, Any]:
    """Tuning + fit final + evaluación + logging para una loss.

    Se corre dentro de un child run de MLflow.

    Returns:
        Dict con el best_value del tuning, las métricas globales y la
        ruta del modelo guardado.
    """
    with mlflow.start_run(
        run_name=f"loss_{loss_config_name}",
        nested=True,
    ) as run:
        # --- Config snapshot ---
        loss_cfg = cfg.LOSS_CONFIGS[loss_config_name]
        log_config_snapshot(
            extra={
                "loss_config_name": loss_config_name,
                "xgb_objective": loss_cfg["xgb_objective"],
                "target_transform": loss_cfg["target_transform"],
                "n_features_final": len(selected_features),
            }
        )
        mlflow.set_tag("loss_description", loss_cfg["description"])

        # --- Tuning ---
        result = run_study(
            X=X_train,
            y=y_train,
            loss_config_name=loss_config_name,
        )

        # Log best params
        mlflow.log_params({f"best_{k}": v for k, v in result.best_params.items()})
        mlflow.log_metric("tuning_best_rmse_val", result.best_value)
        mlflow.log_metric("tuning_n_trials", result.n_trials)

        # --- Fit final ---
        model = train_final_model(
            X_train=X_train,
            y_train=y_train,
            best_params=result.best_params,
            loss_config_name=loss_config_name,
        )

        # --- Evaluación en test ---
        y_pred = predict_original_scale(model, X_test, loss_config_name)
        evaluation = full_evaluation(y_test.to_numpy(), y_pred)

        # Métricas planas -> MLflow
        flat = flatten_metrics_for_mlflow(evaluation, prefix="test_")
        log_metrics(flat)

        # Tablas completas -> artefactos
        log_dataframe_csv(evaluation["by_decile"], "metrics_by_decile.csv")
        log_dataframe_csv(evaluation["range_counts"], "range_confusion_counts.csv")
        log_dataframe_csv(evaluation["range_row_pct"], "range_confusion_row_pct.csv")

        # --- Guardar modelo ---
        model_path = cfg.MODELS_DIR / f"xgb_{loss_config_name}.json"
        metadata = {
            "loss_config_name": loss_config_name,
            "xgb_objective": loss_cfg["xgb_objective"],
            "target_transform": loss_cfg["target_transform"],
            "best_params": result.best_params,
            "n_features": len(selected_features),
            "features": selected_features,
            "trained_at": datetime.utcnow().isoformat(),
            "test_metrics_global": evaluation["global"],
        }
        save_model_json(model, model_path, extra_metadata=metadata)
        log_model_json(model_path)

        # Listado de features también como artefacto
        features_path = cfg.MODELS_DIR / f"features_{loss_config_name}.json"
        save_json(selected_features, features_path)
        mlflow.log_artifact(str(features_path), artifact_path="model")

        return {
            "loss_config_name": loss_config_name,
            "run_id": run.info.run_id,
            "tuning_best_rmse_val": result.best_value,
            "test_rmse": evaluation["global"]["rmse"],
            "test_mae": evaluation["global"]["mae"],
            "test_r2": evaluation["global"]["r2"],
            "test_spearman": evaluation["global"]["spearman"],
            "test_diag_exact": evaluation["diagonal"]["diag_exact"],
            "test_diag_pm3": evaluation["diagonal"]["diag_pm3"],
            "model_path": str(model_path),
            "features_path": str(features_path),
        }


# =============================================================================
# Entrada pública
# =============================================================================


def run_pipeline(
    train_path: Path = cfg.TRAIN_FILE,
    test_path: Path = cfg.TEST_FILE,
    top_k: int = cfg.TOP_K_FEATURES,
) -> dict[str, Any]:
    """Corre el pipeline end-to-end.

    Args:
        train_path: CSV de train.
        test_path: CSV de test.
        top_k: K para feature engineering combinatorial.

    Returns:
        Dict resumen con los resultados de cada loss y cuál ganó.
    """
    set_global_seed(cfg.RANDOM_SEED)
    init_mlflow()

    run_name = f"pipeline_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}"
    logger.info(f"=== Iniciando pipeline: {run_name} ===")

    with mlflow.start_run(run_name=run_name) as parent_run:
        log_config_snapshot(extra={"top_k_features_used": top_k})
        mlflow.set_tag("stage", "parent")

        # ---- Etapas 1-2 ----
        X_tr, y_tr, X_te, y_te, preprocessor = stage_load_and_preprocess(
            train_path=train_path, test_path=test_path
        )
        preprocessor.save(cfg.MODELS_DIR / "preprocessor.pkl")
        mlflow.log_artifact(
            str(cfg.MODELS_DIR / "preprocessor.pkl"), artifact_path="preprocessing"
        )

        # ---- Etapas 3-5 ----
        X_tr_sel, X_te_sel, df_rank_final, selected = stage_feature_engineering(
            X_train=X_tr, y_train=y_tr, X_test=X_te, top_k=top_k
        )
        # Artefactos de selección
        log_dataframe_csv(df_rank_final, "feature_ranking_final.csv")
        save_json(selected, cfg.MODELS_DIR / "feature_list.json")
        mlflow.log_artifact(
            str(cfg.MODELS_DIR / "feature_list.json"), artifact_path="selection"
        )

        # ---- Etapas 6-9 por loss ----
        results_per_loss = []
        for loss_name in cfg.LOSS_CONFIGS.keys():
            r = stage_tune_and_evaluate_one_loss(
                loss_config_name=loss_name,
                X_train=X_tr_sel,
                y_train=y_tr,
                X_test=X_te_sel,
                y_test=y_te,
                parent_run_id=parent_run.info.run_id,
                selected_features=selected,
            )
            results_per_loss.append(r)

        # ---- Resumen comparativo en el parent run ----
        df_summary = pd.DataFrame(results_per_loss)
        log_dataframe_csv(df_summary, "loss_comparison_summary.csv")

        # Modelo ganador: mínimo test_rmse
        winner = min(results_per_loss, key=lambda r: r["test_rmse"])
        mlflow.set_tag("winner_loss", winner["loss_config_name"])
        mlflow.log_metric("winner_test_rmse", winner["test_rmse"])
        mlflow.log_metric("winner_test_r2", winner["test_r2"])

        logger.info("=" * 70)
        logger.info(f"GANADOR: {winner['loss_config_name']}")
        logger.info(
            f"  test_rmse={winner['test_rmse']:.1f} "
            f"test_mae={winner['test_mae']:.1f} "
            f"test_r2={winner['test_r2']:.4f} "
            f"spearman={winner['test_spearman']:.4f}"
        )
        logger.info("=" * 70)

        return {
            "run_name": run_name,
            "parent_run_id": parent_run.info.run_id,
            "results_per_loss": results_per_loss,
            "winner": winner,
        }


if __name__ == "__main__":
    run_pipeline()
