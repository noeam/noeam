"""Evaluación exhaustiva de modelos de regresión.

Contiene todas las métricas que el pipeline registra en MLflow:

    Globales:
        - RMSE, MAE, MedAE, R², explained_variance
        - Pearson, Spearman
        - SMAPE (robusta a ceros, a diferencia de MAPE)

    Por decil del target real:
        - RMSE / MAE / MedAE por decil

    Extremos (según config.EXTREME_LOWER_Q / EXTREME_UPPER_Q):
        - Métricas restringidas a la cola inferior y superior
        - "Recall" de extremos: de los que están realmente en el extremo,
          qué % los predice el modelo también en el extremo.

    Matriz de rangos:
        - Crosstab real vs predicho con los bins de negocio.
        - % de aciertos en la diagonal exacta, ±1, ±2, ±3.
"""

from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd
from scipy import stats
from sklearn import metrics as skm

from . import config as cfg
from .utils import setup_logger

logger = setup_logger(__name__)


# =============================================================================
# Helpers
# =============================================================================


def _smape(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """Symmetric MAPE, robusta a ceros en el denominador."""
    num = np.abs(y_pred - y_true)
    den = (np.abs(y_true) + np.abs(y_pred)) / 2.0
    # Evitar 0/0 cuando real y pred son 0
    mask = den > 0
    if not mask.any():
        return 0.0
    return float(np.mean(num[mask] / den[mask]) * 100.0)


def _safe_spearman(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """Spearman con manejo de fallas numéricas."""
    try:
        return float(stats.spearmanr(y_true, y_pred).correlation)
    except Exception:
        return float("nan")


# =============================================================================
# Métricas globales
# =============================================================================


def global_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> dict[str, float]:
    """Métricas globales del modelo.

    Args:
        y_true: Target real en la escala original.
        y_pred: Predicción en la escala original.

    Returns:
        Dict plano listo para loggear en MLflow.
    """
    y_true = np.asarray(y_true, dtype=np.float64)
    y_pred = np.asarray(y_pred, dtype=np.float64)

    return {
        "rmse": float(np.sqrt(skm.mean_squared_error(y_true, y_pred))),
        "mae": float(skm.mean_absolute_error(y_true, y_pred)),
        "medae": float(skm.median_absolute_error(y_true, y_pred)),
        "r2": float(skm.r2_score(y_true, y_pred)),
        "explained_variance": float(skm.explained_variance_score(y_true, y_pred)),
        "pearson": float(np.corrcoef(y_true, y_pred)[0, 1]),
        "spearman": _safe_spearman(y_true, y_pred),
        "smape_pct": _smape(y_true, y_pred),
    }


# =============================================================================
# Métricas por decil del target real
# =============================================================================


def metrics_by_decile(
    y_true: np.ndarray, y_pred: np.ndarray, n_bins: int = 10
) -> pd.DataFrame:
    """Descompone las métricas por decil del target real.

    Sirve para detectar si el modelo falla sistemáticamente en los
    extremos o en algún tramo particular.

    Args:
        y_true: Target real.
        y_pred: Predicción.
        n_bins: Número de bins (default 10 = deciles).

    Returns:
        DataFrame indexado por decil con RMSE/MAE/MedAE y tamaño.
    """
    y_true = np.asarray(y_true, dtype=np.float64)
    y_pred = np.asarray(y_pred, dtype=np.float64)

    bins = pd.qcut(y_true, q=n_bins, duplicates="drop")
    df = pd.DataFrame({"y_true": y_true, "y_pred": y_pred, "bin": bins})

    out = (
        df.groupby("bin", observed=True)
        .apply(
            lambda g: pd.Series(
                {
                    "n": len(g),
                    "y_min": g["y_true"].min(),
                    "y_max": g["y_true"].max(),
                    "rmse": np.sqrt(skm.mean_squared_error(g["y_true"], g["y_pred"])),
                    "mae": skm.mean_absolute_error(g["y_true"], g["y_pred"]),
                    "medae": skm.median_absolute_error(g["y_true"], g["y_pred"]),
                }
            )
        )
        .reset_index()
    )
    return out


# =============================================================================
# Métricas de extremos
# =============================================================================


def extreme_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    lower_q: float = cfg.EXTREME_LOWER_Q,
    upper_q: float = cfg.EXTREME_UPPER_Q,
) -> dict[str, float]:
    """Métricas restringidas a las colas del target.

    Args:
        y_true: Target real.
        y_pred: Predicción.
        lower_q: Cuantil de la cola inferior (default 0.02).
        upper_q: Cuantil de la cola superior (default 0.98).

    Returns:
        Dict con métricas por cola y recall de extremos.
    """
    y_true = np.asarray(y_true, dtype=np.float64)
    y_pred = np.asarray(y_pred, dtype=np.float64)

    q_low = np.quantile(y_true, lower_q)
    q_high = np.quantile(y_true, upper_q)

    mask_low_true = y_true <= q_low
    mask_high_true = y_true >= q_high

    # Umbrales en la predicción (mismo cuantil)
    q_low_pred = np.quantile(y_pred, lower_q)
    q_high_pred = np.quantile(y_pred, upper_q)
    mask_low_pred = y_pred <= q_low_pred
    mask_high_pred = y_pred >= q_high_pred

    out: dict[str, float] = {
        "threshold_lower": float(q_low),
        "threshold_upper": float(q_high),
        "n_lower_extreme": int(mask_low_true.sum()),
        "n_upper_extreme": int(mask_high_true.sum()),
    }

    # Métricas en cada cola
    if mask_low_true.any():
        yt, yp = y_true[mask_low_true], y_pred[mask_low_true]
        out.update(
            {
                "lower_rmse": float(np.sqrt(skm.mean_squared_error(yt, yp))),
                "lower_mae": float(skm.mean_absolute_error(yt, yp)),
                "lower_medae": float(skm.median_absolute_error(yt, yp)),
                "lower_spearman": _safe_spearman(yt, yp),
            }
        )
    if mask_high_true.any():
        yt, yp = y_true[mask_high_true], y_pred[mask_high_true]
        out.update(
            {
                "upper_rmse": float(np.sqrt(skm.mean_squared_error(yt, yp))),
                "upper_mae": float(skm.mean_absolute_error(yt, yp)),
                "upper_medae": float(skm.median_absolute_error(yt, yp)),
                "upper_spearman": _safe_spearman(yt, yp),
            }
        )

    # Recall de extremos: de los que realmente son extremos,
    # ¿qué % predice el modelo también en su propio extremo?
    if mask_low_true.sum() > 0:
        out["recall_lower_extreme"] = float(
            (mask_low_true & mask_low_pred).sum() / mask_low_true.sum()
        )
    if mask_high_true.sum() > 0:
        out["recall_upper_extreme"] = float(
            (mask_high_true & mask_high_pred).sum() / mask_high_true.sum()
        )

    return out


# =============================================================================
# Matriz de rangos (bins de negocio)
# =============================================================================


def range_confusion_matrix(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    bin_edges: np.ndarray = cfg.BIN_EDGES,
    bin_labels: list[str] = cfg.BIN_LABELS,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Construye la matriz de confusión por rangos.

    Args:
        y_true: Target real.
        y_pred: Predicción.
        bin_edges: Cortes de los bins.
        bin_labels: Labels de los bins (len == len(bin_edges) - 1).

    Returns:
        Tupla ``(counts, row_pct)``:
            - ``counts``: Conteos absolutos.
            - ``row_pct``: % por fila (dado un rango real, distribución
              de rangos predichos).
    """
    y_true_bin = pd.cut(y_true, bins=bin_edges, labels=bin_labels, include_lowest=True)
    y_pred_bin = pd.cut(y_pred, bins=bin_edges, labels=bin_labels, include_lowest=True)

    counts = pd.crosstab(
        y_true_bin, y_pred_bin, rownames=["real"], colnames=["pred"], dropna=False
    )
    # Asegurar orden y completitud de índices/columnas
    counts = counts.reindex(index=bin_labels, columns=bin_labels, fill_value=0)

    row_sums = counts.sum(axis=1).replace(0, np.nan)
    row_pct = counts.div(row_sums, axis=0).fillna(0.0) * 100.0

    return counts, row_pct


def diagonal_hit_rates(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    bin_edges: np.ndarray = cfg.BIN_EDGES,
    bin_labels: list[str] = cfg.BIN_LABELS,
    tolerances: list[int] = cfg.DIAGONAL_TOLERANCES,
) -> dict[str, float]:
    """Porcentaje de observaciones cuya predicción cae en la diagonal ± k.

    Args:
        y_true: Target real.
        y_pred: Predicción.
        bin_edges: Cortes.
        bin_labels: Labels.
        tolerances: Valores de k a evaluar.

    Returns:
        Dict con claves ``diag_exact``, ``diag_pm1``, ``diag_pm2``,
        ``diag_pm3`` (según tolerancias pedidas).
    """
    idx_true = pd.cut(
        y_true, bins=bin_edges, labels=False, include_lowest=True
    ).astype("Int64")
    idx_pred = pd.cut(
        y_pred, bins=bin_edges, labels=False, include_lowest=True
    ).astype("Int64")

    # NaNs aparecen si el valor cae fuera de los bin_edges (no debería ocurrir
    # al incluir ±inf, pero por robustez).
    mask_valid = idx_true.notna() & idx_pred.notna()
    diff = (idx_true[mask_valid] - idx_pred[mask_valid]).abs()

    out: dict[str, float] = {}
    n = len(diff)
    for k in tolerances:
        label = "diag_exact" if k == 0 else f"diag_pm{k}"
        out[label] = float((diff <= k).sum() / n) if n > 0 else 0.0
    return out


# =============================================================================
# Reporte completo
# =============================================================================


def full_evaluation(
    y_true: np.ndarray, y_pred: np.ndarray
) -> dict[str, Any]:
    """Ejecuta todas las evaluaciones y devuelve un dict consolidado.

    Args:
        y_true: Target real en escala original.
        y_pred: Predicción en escala original (ya invertida si aplica).

    Returns:
        Dict con keys: ``global``, ``by_decile``, ``extremes``,
        ``diagonal``, ``range_counts``, ``range_row_pct``.
    """
    y_true = np.asarray(y_true, dtype=np.float64)
    y_pred = np.asarray(y_pred, dtype=np.float64)

    g = global_metrics(y_true, y_pred)
    by_dec = metrics_by_decile(y_true, y_pred)
    ext = extreme_metrics(y_true, y_pred)
    diag = diagonal_hit_rates(y_true, y_pred)
    counts, row_pct = range_confusion_matrix(y_true, y_pred)

    logger.info(
        f"EVAL | RMSE={g['rmse']:.1f} MAE={g['mae']:.1f} R2={g['r2']:.4f} "
        f"Spear={g['spearman']:.4f} | diag={diag['diag_exact']:.3f} "
        f"pm1={diag['diag_pm1']:.3f} pm3={diag['diag_pm3']:.3f}"
    )

    return {
        "global": g,
        "by_decile": by_dec,
        "extremes": ext,
        "diagonal": diag,
        "range_counts": counts,
        "range_row_pct": row_pct,
    }


def flatten_metrics_for_mlflow(
    evaluation: dict[str, Any], prefix: str = ""
) -> dict[str, float]:
    """Aplana el dict de evaluación para loggearlo como métricas escalares.

    Args:
        evaluation: Output de :func:`full_evaluation`.
        prefix: Prefijo opcional (p.ej. "test_").

    Returns:
        Dict plano con solo floats/ints.
    """
    flat: dict[str, float] = {}
    for k, v in evaluation["global"].items():
        flat[f"{prefix}{k}"] = v
    for k, v in evaluation["extremes"].items():
        flat[f"{prefix}ext_{k}"] = v
    for k, v in evaluation["diagonal"].items():
        flat[f"{prefix}{k}"] = v
    # Por decil: logueamos solo RMSE/MAE del decil más bajo y más alto
    byd = evaluation["by_decile"]
    if len(byd) > 0:
        flat[f"{prefix}decile_low_rmse"] = float(byd.iloc[0]["rmse"])
        flat[f"{prefix}decile_low_mae"] = float(byd.iloc[0]["mae"])
        flat[f"{prefix}decile_high_rmse"] = float(byd.iloc[-1]["rmse"])
        flat[f"{prefix}decile_high_mae"] = float(byd.iloc[-1]["mae"])
    return flat
