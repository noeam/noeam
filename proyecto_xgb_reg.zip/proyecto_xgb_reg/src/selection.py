"""Selección de variables por ganancia (gain) con XGBoost.

Entrena un XGBoost baseline sobre todas las features, extrae la
importancia por ``gain`` y devuelve un DataFrame ordenado. Se usa dos
veces en el pipeline:

    1. Ranking inicial sobre features originales -> top-k para FE.
    2. Ranking final sobre (originales + generadas) -> features del
       modelo definitivo.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import xgboost as xgb

from . import config as cfg
from .utils import setup_logger

logger = setup_logger(__name__)


def baseline_params(device: str = cfg.DEVICE, seed: int = cfg.RANDOM_SEED) -> dict:
    """Hiperparámetros razonables para un fit rápido de ranking.

    No buscan el óptimo, solo dar un gain estable.
    """
    return {
        "objective": "reg:squarederror",
        "tree_method": "hist",
        "device": device,
        "learning_rate": 0.1,
        "max_depth": 6,
        "min_child_weight": 5,
        "subsample": 0.9,
        "colsample_bytree": 0.9,
        "reg_lambda": 1.0,
        "seed": seed,
        "verbosity": 0,
    }


def rank_by_gain(
    X: pd.DataFrame,
    y: pd.Series | np.ndarray,
    n_estimators: int = 300,
    enable_categorical: bool = True,
    device: str = cfg.DEVICE,
    seed: int = cfg.RANDOM_SEED,
) -> pd.DataFrame:
    """Ajusta un XGBoost baseline y extrae gain por feature.

    Args:
        X: DataFrame con features ya preprocesadas.
        y: Target (en la escala original o transformada; el ranking por
            gain es robusto a transformaciones monótonas).
        n_estimators: Nº de árboles para el fit baseline.
        enable_categorical: Activa soporte nativo de categóricas.
        device: "cuda" o "cpu".
        seed: Semilla.

    Returns:
        DataFrame con columnas ``feature`` y ``gain`` ordenadas desc.
    """
    logger.info(f"Ranking por gain: {X.shape[1]} features, {len(X):,} filas, device={device}")

    params = baseline_params(device=device, seed=seed)
    model = xgb.XGBRegressor(
        n_estimators=n_estimators,
        enable_categorical=enable_categorical,
        **params,
    )
    model.fit(X, y, verbose=False)

    booster = model.get_booster()
    score = booster.get_score(importance_type="gain")

    # Construir DataFrame con todas las features (las no usadas -> gain=0)
    all_features = list(X.columns)
    rows = [{"feature": f, "gain": score.get(f, 0.0)} for f in all_features]
    df_rank = (
        pd.DataFrame(rows)
        .sort_values("gain", ascending=False)
        .reset_index(drop=True)
    )
    logger.info(
        f"Top 5 por gain: "
        + ", ".join(f"{r['feature']}({r['gain']:.1f})" for _, r in df_rank.head().iterrows())
    )
    return df_rank


def top_k_features(df_rank: pd.DataFrame, k: int) -> list[str]:
    """Devuelve las top-k features del ranking.

    Args:
        df_rank: DataFrame devuelto por :func:`rank_by_gain`.
        k: Cuántas features tomar.

    Returns:
        Lista de nombres de features.
    """
    return df_rank.head(k)["feature"].tolist()
