"""Feature engineering combinatorial sobre top-k variables.

Dado un conjunto reducido de features más importantes por gain,
genera sistemáticamente interacciones y transformaciones:

    - Productos:   x_i * x_j  (pares únicos)
    - Ratios:      x_i / x_j  (con protección epsilon)
    - Diferencias: x_i - x_j
    - Cuadrados:   x_i^2
    - Signed sqrt: sign(x) * sqrt(|x|)
    - Signed log:  sign(x) * log1p(|x|)

Cada familia es opcional vía :data:`config.FE_FAMILIES`. Las columnas
generadas usan un prefijo que identifica la familia para poder
auditarlas después.
"""

from __future__ import annotations

from itertools import combinations

import numpy as np
import pandas as pd

from . import config as cfg
from .utils import setup_logger

logger = setup_logger(__name__)


def _safe_ratio(a: np.ndarray, b: np.ndarray, eps: float) -> np.ndarray:
    """Calcula a/b protegido contra división por cero.

    Si ``|b| < eps``, retorna 0 en esa posición.
    """
    denom = np.where(np.abs(b) < eps, np.nan, b)
    out = a / denom
    return np.nan_to_num(out, nan=0.0, posinf=0.0, neginf=0.0)


def generate_combinatorial_features(
    X: pd.DataFrame,
    base_features: list[str],
    families: dict[str, bool] = cfg.FE_FAMILIES,
    eps: float = cfg.RATIO_EPS,
) -> pd.DataFrame:
    """Genera features combinatorias sobre un subconjunto de columnas.

    Args:
        X: DataFrame de entrada (se mantiene intacto).
        base_features: Columnas sobre las que iterar. Solo deben ser
            numéricas; las categóricas deben excluirse antes.
        families: Dict con flags por familia (ver config.FE_FAMILIES).
        eps: Umbral para división segura en ratios.

    Returns:
        DataFrame con las columnas nuevas (no incluye las originales).
    """
    logger.info(f"Feature engineering sobre {len(base_features)} variables base.")

    # Filtrar a numéricas existentes
    base_features = [
        c
        for c in base_features
        if c in X.columns and pd.api.types.is_numeric_dtype(X[c])
    ]
    if not base_features:
        logger.warning("No hay variables numéricas en el top-k; se omite FE.")
        return pd.DataFrame(index=X.index)

    new_cols: dict[str, np.ndarray] = {}
    pairs = list(combinations(base_features, 2))
    logger.info(f"  pares generados: {len(pairs)}")

    # --- Univariadas ---
    for c in base_features:
        x = X[c].to_numpy(dtype=np.float64)
        if families.get("squares"):
            new_cols[f"sq__{c}"] = (x ** 2).astype(np.float32)
        if families.get("signed_sqrt"):
            new_cols[f"ssqrt__{c}"] = (np.sign(x) * np.sqrt(np.abs(x))).astype(np.float32)
        if families.get("signed_log1p"):
            new_cols[f"slog__{c}"] = (np.sign(x) * np.log1p(np.abs(x))).astype(np.float32)

    # --- Bivariadas ---
    for a, b in pairs:
        xa = X[a].to_numpy(dtype=np.float64)
        xb = X[b].to_numpy(dtype=np.float64)

        if families.get("products"):
            new_cols[f"prod__{a}__{b}"] = (xa * xb).astype(np.float32)
        if families.get("diffs"):
            new_cols[f"diff__{a}__{b}"] = (xa - xb).astype(np.float32)
        if families.get("ratios"):
            # Un solo sentido para evitar duplicar dimensionalidad.
            new_cols[f"ratio__{a}__{b}"] = _safe_ratio(xa, xb, eps).astype(np.float32)

    df_new = pd.DataFrame(new_cols, index=X.index)
    logger.info(f"  features generadas: {df_new.shape[1]}")
    return df_new


def combine_features(
    X_original: pd.DataFrame, X_new: pd.DataFrame
) -> pd.DataFrame:
    """Concatena originales + nuevas por columnas."""
    if X_new.shape[1] == 0:
        return X_original
    return pd.concat([X_original, X_new], axis=1)
