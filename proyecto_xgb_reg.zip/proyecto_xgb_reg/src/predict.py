"""Inferencia sobre nuevos datos usando el modelo guardado.

Uso:
    python -m src.predict \\
        --input data/raw/new_data.csv \\
        --model models/xgb_B_squared_signedlog1p.json \\
        --output reports/predictions.csv

Reconstruye el pipeline de preprocesamiento a partir del
``preprocessor.pkl`` y la lista de features a partir del
``features_*.json`` asociado al modelo.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
import xgboost as xgb

from . import config as cfg
from .data import load_raw_csv, split_features_target
from .features import combine_features, generate_combinatorial_features
from .preprocessing import Preprocessor, inverse_target_transform
from .selection import rank_by_gain, top_k_features  # noqa: F401  (por si se reusa)
from .utils import load_json, setup_logger

logger = setup_logger(__name__)


def predict_from_csv(
    input_csv: Path,
    model_path: Path,
    output_csv: Path,
    preprocessor_path: Path = cfg.MODELS_DIR / "preprocessor.pkl",
    feature_list_path: Path | None = None,
) -> pd.DataFrame:
    """Infiera el target en un CSV nuevo.

    Args:
        input_csv: CSV con la misma estructura que train (puede no
            tener la columna target).
        model_path: JSON del modelo XGBoost.
        output_csv: Ruta destino del CSV con predicciones.
        preprocessor_path: Preprocessor serializado.
        feature_list_path: JSON con el orden de features. Si es None,
            se infiere del sidecar ``<model>.meta.json``.

    Returns:
        DataFrame con columnas ``id`` y ``y_pred``.
    """
    # --- Cargar metadata del modelo ---
    meta_path = model_path.with_suffix(".meta.json")
    if not meta_path.exists():
        raise FileNotFoundError(f"No se encontró metadata del modelo: {meta_path}")
    meta = load_json(meta_path)
    loss_config_name = meta["loss_config_name"]
    target_transform = meta["target_transform"]

    if feature_list_path is None:
        features = meta["features"]
    else:
        features = load_json(feature_list_path)

    logger.info(f"Cargando modelo [{loss_config_name}] desde {model_path}")
    booster = xgb.Booster()
    booster.load_model(str(model_path))

    # --- Cargar datos ---
    df = load_raw_csv(input_csv)
    X, _, ids = split_features_target(df)

    # --- Preprocesar ---
    preprocessor: Preprocessor = Preprocessor.load(preprocessor_path)
    X_pp = preprocessor.transform(X)

    # --- Reproducir feature engineering ---
    # Derivamos el top-k original a partir de los nombres de las
    # features generadas (prefijos prod__, ratio__, etc.) cuando las
    # hay; si no, cualquier feature seleccionada que sea original ya
    # está en X_pp.
    base_features_for_fe = sorted(
        set(
            name.split("__")[1]
            for name in features
            if "__" in name and name.split("__")[0] in {"prod", "ratio", "diff"}
        ).union(
            set(
                name.split("__")[1]
                for name in features
                if "__" in name and name.split("__")[0] in {"sq", "ssqrt", "slog"}
            )
        )
    )
    if base_features_for_fe:
        X_new = generate_combinatorial_features(X_pp, base_features_for_fe)
        X_full = combine_features(X_pp, X_new)
    else:
        X_full = X_pp

    # --- Seleccionar features en el orden exacto del entrenamiento ---
    missing = [f for f in features if f not in X_full.columns]
    if missing:
        logger.warning(f"Features faltantes (se rellenan con 0): {missing[:5]} ...")
        for f in missing:
            X_full[f] = 0.0
    X_final = X_full[features]

    # --- Predecir e invertir transformación ---
    dmat = xgb.DMatrix(X_final, enable_categorical=True)
    pred_tx = booster.predict(dmat)
    pred = inverse_target_transform(pred_tx, target_transform)

    # --- Output ---
    out = pd.DataFrame({"y_pred": pred})
    if ids is not None:
        out.insert(0, cfg.ID_COL, ids.values)

    output_csv.parent.mkdir(parents=True, exist_ok=True)
    out.to_csv(output_csv, index=False)
    logger.info(f"Predicciones guardadas en {output_csv} ({len(out):,} filas)")
    return out


def _cli() -> None:
    parser = argparse.ArgumentParser(description="Inferencia con modelo XGBoost.")
    parser.add_argument("--input", type=Path, required=True, help="CSV de entrada.")
    parser.add_argument(
        "--model", type=Path, required=True, help="Ruta al .json del modelo."
    )
    parser.add_argument(
        "--output", type=Path, required=True, help="CSV de salida con predicciones."
    )
    parser.add_argument(
        "--preprocessor",
        type=Path,
        default=cfg.MODELS_DIR / "preprocessor.pkl",
        help="Preprocessor serializado.",
    )
    parser.add_argument(
        "--features",
        type=Path,
        default=None,
        help="JSON con lista de features (opcional; se infiere de la meta).",
    )
    args = parser.parse_args()
    predict_from_csv(
        input_csv=args.input,
        model_path=args.model,
        output_csv=args.output,
        preprocessor_path=args.preprocessor,
        feature_list_path=args.features,
    )


if __name__ == "__main__":
    _cli()
