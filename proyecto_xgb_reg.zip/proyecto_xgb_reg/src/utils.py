"""Utilidades transversales: logging, semillas, IO."""

from __future__ import annotations

import json
import logging
import os
import random
import sys
from pathlib import Path
from typing import Any

import numpy as np


def setup_logger(name: str = "xgb_reg", level: int = logging.INFO) -> logging.Logger:
    """Configura logger con salida a stdout.

    Args:
        name: Nombre del logger.
        level: Nivel de logging (INFO por default).

    Returns:
        Logger configurado, idempotente entre llamadas.
    """
    logger = logging.getLogger(name)
    if logger.handlers:
        return logger

    logger.setLevel(level)
    handler = logging.StreamHandler(sys.stdout)
    formatter = logging.Formatter(
        "%(asctime)s | %(name)s | %(levelname)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.propagate = False
    return logger


def set_global_seed(seed: int = 42) -> None:
    """Fija semilla global en numpy, random y env vars.

    Args:
        seed: Semilla entera.
    """
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)
    np.random.seed(seed)


def save_json(obj: Any, path: Path) -> None:
    """Serializa un objeto a JSON (maneja numpy)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False, default=_json_default)


def load_json(path: Path) -> Any:
    """Carga JSON desde disco."""
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def _json_default(o: Any) -> Any:
    """Serializador auxiliar para tipos numpy."""
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.floating,)):
        return float(o)
    if isinstance(o, np.ndarray):
        return o.tolist()
    if isinstance(o, Path):
        return str(o)
    raise TypeError(f"Tipo no serializable: {type(o)}")
