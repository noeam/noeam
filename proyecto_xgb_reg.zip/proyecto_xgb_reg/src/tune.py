"""Tuning de hiperparámetros con Optuna.

Usa TPE + MedianPruner con early-stopping nativo de XGBoost. Cada trial
respeta el presupuesto de tiempo configurado en
:data:`config.TUNING_TIMEOUT_SEC_PER_LOSS` y el cap de trials en
:data:`config.TUNING_N_TRIALS_MAX`.

La función objetivo optimiza **RMSE en la escala original del target**
(no en la transformada) usando validación interna hold-out. Esto
garantiza que las dos losses comparadas (A y B) se evalúen en la misma
escala y sean directamente comparables.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

import numpy as np
import optuna
import pandas as pd
import xgboost as xgb
from optuna.pruners import MedianPruner
from optuna.samplers import TPESampler
from sklearn.model_selection import train_test_split

from . import config as cfg
from .preprocessing import (
    TargetTransform,
    apply_target_transform,
    inverse_target_transform,
)
from .utils import setup_logger

logger = setup_logger(__name__)


# =============================================================================
# Contenedor de resultados
# =============================================================================


@dataclass
class TuningResult:
    """Resultado de un tuning."""

    best_params: dict[str, Any]
    best_value: float
    n_trials: int
    loss_config_name: str
    study: optuna.Study


# =============================================================================
# Espacio de búsqueda
# =============================================================================


def _suggest_xgb_params(
    trial: optuna.Trial,
    space: dict[str, tuple] = cfg.XGB_PARAM_SPACE,
    include_huber_slope: bool = False,
) -> dict[str, Any]:
    """Propone hiperparámetros dentro del espacio definido.

    Args:
        trial: Trial de Optuna.
        space: Dict con rangos por hiperparámetro.
        include_huber_slope: Solo para ``reg:pseudohubererror``.

    Returns:
        Dict de hiperparámetros.
    """
    params = {
        "n_estimators": trial.suggest_int(
            "n_estimators", *space["n_estimators"]
        ),
        "max_depth": trial.suggest_int("max_depth", *space["max_depth"]),
        "learning_rate": trial.suggest_float(
            "learning_rate", *space["learning_rate"], log=True
        ),
        "min_child_weight": trial.suggest_int(
            "min_child_weight", *space["min_child_weight"]
        ),
        "subsample": trial.suggest_float("subsample", *space["subsample"]),
        "colsample_bytree": trial.suggest_float(
            "colsample_bytree", *space["colsample_bytree"]
        ),
        "colsample_bylevel": trial.suggest_float(
            "colsample_bylevel", *space["colsample_bylevel"]
        ),
        "reg_alpha": trial.suggest_float(
            "reg_alpha", *space["reg_alpha"], log=True
        ),
        "reg_lambda": trial.suggest_float(
            "reg_lambda", *space["reg_lambda"], log=True
        ),
        "gamma": trial.suggest_float("gamma", *space["gamma"], log=True),
    }
    if include_huber_slope:
        params["huber_slope"] = trial.suggest_float(
            "huber_slope", *space["huber_slope"]
        )
    return params


# =============================================================================
# Función objetivo
# =============================================================================


def _build_objective(
    X: pd.DataFrame,
    y: pd.Series,
    loss_config_name: str,
    device: str = cfg.DEVICE,
    seed: int = cfg.RANDOM_SEED,
    val_size: float = cfg.VAL_SIZE,
) -> Callable[[optuna.Trial], float]:
    """Construye la función objetivo de Optuna.

    Se hace un único split train/val reproducible; cada trial reusa
    ese split para que las comparaciones entre trials sean justas.

    Args:
        X: Features preprocesadas con FE aplicado.
        y: Target en escala original.
        loss_config_name: Clave de :data:`config.LOSS_CONFIGS`.
        device: "cuda" o "cpu".
        seed: Semilla.
        val_size: Fracción para validación interna.

    Returns:
        Función objetivo compatible con Optuna.
    """
    loss_cfg = cfg.LOSS_CONFIGS[loss_config_name]
    objective_str: str = loss_cfg["xgb_objective"]
    target_transform: TargetTransform = loss_cfg["target_transform"]
    is_huber = objective_str == "reg:pseudohubererror"

    X_tr, X_va, y_tr, y_va = train_test_split(
        X, y, test_size=val_size, random_state=seed
    )

    # El target se transforma ANTES de entrenar y se desinvierte al evaluar.
    y_tr_tx = apply_target_transform(y_tr.to_numpy(), target_transform)
    y_va_tx = apply_target_transform(y_va.to_numpy(), target_transform)
    y_va_orig = y_va.to_numpy(dtype=np.float64)

    def objective(trial: optuna.Trial) -> float:
        params = _suggest_xgb_params(trial, include_huber_slope=is_huber)

        xgb_params = {
            "objective": objective_str,
            "tree_method": "hist",
            "device": device,
            "enable_categorical": True,
            "eval_metric": "rmse",
            "random_state": seed,
            "verbosity": 0,
            **params,
        }
        n_estimators = xgb_params.pop("n_estimators")

        # Callback de pruning en la métrica de validación
        pruning_cb = optuna.integration.XGBoostPruningCallback(
            trial, "validation_0-rmse"
        )

        model = xgb.XGBRegressor(
            n_estimators=n_estimators,
            early_stopping_rounds=50,
            callbacks=[pruning_cb],
            **xgb_params,
        )
        model.fit(
            X_tr,
            y_tr_tx,
            eval_set=[(X_va, y_va_tx)],
            verbose=False,
        )

        # Predicción en escala transformada -> invertir -> métrica en
        # escala original para comparar losses entre sí.
        pred_tx = model.predict(X_va)
        pred_orig = inverse_target_transform(pred_tx, target_transform)
        rmse_orig = float(np.sqrt(np.mean((y_va_orig - pred_orig) ** 2)))

        # Loggeamos también el best_iteration para reconstruir el modelo
        trial.set_user_attr("best_iteration", int(model.best_iteration or n_estimators))
        return rmse_orig

    return objective


# =============================================================================
# Entrada pública
# =============================================================================


def run_study(
    X: pd.DataFrame,
    y: pd.Series,
    loss_config_name: str,
    timeout: int = cfg.TUNING_TIMEOUT_SEC_PER_LOSS,
    n_trials: int = cfg.TUNING_N_TRIALS_MAX,
    device: str = cfg.DEVICE,
    seed: int = cfg.RANDOM_SEED,
) -> TuningResult:
    """Ejecuta un estudio completo de Optuna para una loss.

    Args:
        X: Features preprocesadas.
        y: Target en escala original.
        loss_config_name: Clave en :data:`config.LOSS_CONFIGS`.
        timeout: Presupuesto en segundos.
        n_trials: Cap superior de trials.
        device: "cuda" o "cpu".
        seed: Semilla.

    Returns:
        :class:`TuningResult` con mejores params y el objeto Study.
    """
    logger.info(
        f"=== Tuning [{loss_config_name}] | timeout={timeout}s n_trials_max={n_trials} ==="
    )

    sampler = TPESampler(seed=seed, multivariate=True)
    pruner = MedianPruner(
        n_startup_trials=cfg.PRUNER_STARTUP_TRIALS,
        n_warmup_steps=cfg.PRUNER_WARMUP_STEPS,
    )
    study = optuna.create_study(
        direction="minimize",
        sampler=sampler,
        pruner=pruner,
        study_name=f"xgb_{loss_config_name}",
    )

    objective = _build_objective(
        X=X, y=y, loss_config_name=loss_config_name, device=device, seed=seed
    )

    study.optimize(
        objective,
        n_trials=n_trials,
        timeout=timeout,
        show_progress_bar=False,
        gc_after_trial=True,
    )

    logger.info(
        f"=== Fin tuning [{loss_config_name}] | "
        f"best RMSE={study.best_value:.2f} n_trials={len(study.trials)} ==="
    )

    return TuningResult(
        best_params=study.best_params,
        best_value=float(study.best_value),
        n_trials=len(study.trials),
        loss_config_name=loss_config_name,
        study=study,
    )
