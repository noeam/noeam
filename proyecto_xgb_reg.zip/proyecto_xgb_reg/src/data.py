"""Carga de datos y preparación de splits.

Responsable de leer los CSVs crudos, inferir tipos (numérico vs
categórico), y separar features del target. Si se ejecuta en modo CPU
(USE_GPU=False) y SUBSAMPLE_ROWS_IF_CPU está definido, hace un
muestreo estratificado por deciles del target para poder iterar rápido
en laptop sin sacrificar representatividad de las colas.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from . import config as cfg
from .utils import setup_logger

logger = setup_logger(__name__)


def load_raw_csv(path: Path) -> pd.DataFrame:
    """Lee un CSV crudo con pandas.

    Args:
        path: Ruta al CSV.

    Returns:
        DataFrame con todas las columnas originales.
    """
    logger.info(f"Leyendo CSV: {path}")
    df = pd.read_csv(path, low_memory=False)
    logger.info(f"  -> shape: {df.shape}")
    return df


def infer_column_types(
    df: pd.DataFrame,
    target_col: str = cfg.TARGET_COL,
    id_col: str = cfg.ID_COL,
    known_categorical: list[str] | None = None,
) -> tuple[list[str], list[str]]:
    """Infiere columnas numéricas y categóricas.

    Una columna se clasifica como categórica si:
      - Está en la lista ``known_categorical``, o
      - Su dtype es ``object``/``category``, o
      - Es numérica pero tiene ≤ 20 valores únicos (heurística para
        códigos almacenados como enteros).

    Args:
        df: DataFrame a analizar.
        target_col: Columna objetivo (se excluye).
        id_col: Columna identificador (se excluye).
        known_categorical: Lista opcional de categóricas conocidas.

    Returns:
        Tupla (numeric_cols, categorical_cols).
    """
    known_categorical = known_categorical or []
    exclude = {target_col, id_col}

    categorical: list[str] = []
    numeric: list[str] = []

    for col in df.columns:
        if col in exclude:
            continue
        if col in known_categorical:
            categorical.append(col)
            continue
        if df[col].dtype == "object" or pd.api.types.is_categorical_dtype(df[col]):
            categorical.append(col)
            continue
        # Numérica pero con pocos únicos -> tratar como categórica
        if pd.api.types.is_numeric_dtype(df[col]) and df[col].nunique(dropna=True) <= 20:
            # Heurística conservadora: solo si hay al menos 2 únicos
            if df[col].nunique(dropna=True) >= 2:
                categorical.append(col)
                continue
        if pd.api.types.is_numeric_dtype(df[col]):
            numeric.append(col)

    logger.info(f"Columnas numéricas:   {len(numeric)}")
    logger.info(f"Columnas categóricas: {len(categorical)}")
    return numeric, categorical


def maybe_subsample(
    df: pd.DataFrame,
    target_col: str = cfg.TARGET_COL,
    use_gpu: bool = cfg.USE_GPU,
    subsample_n: int | None = cfg.SUBSAMPLE_ROWS_IF_CPU,
    seed: int = cfg.RANDOM_SEED,
) -> pd.DataFrame:
    """Submuestrea en modo CPU con estratificación por deciles del target.

    Mantiene representatividad de las colas (extremos).

    Args:
        df: DataFrame original.
        target_col: Columna objetivo.
        use_gpu: Si True, no hace nada.
        subsample_n: Tamaño objetivo (None = no submuestrear).
        seed: Semilla.

    Returns:
        DataFrame (posiblemente submuestreado).
    """
    if use_gpu or subsample_n is None or len(df) <= subsample_n:
        return df

    logger.warning(
        f"Modo CPU: submuestreando de {len(df):,} a {subsample_n:,} filas "
        f"(estratificado por decil del target)."
    )
    deciles = pd.qcut(df[target_col], q=10, duplicates="drop")
    frac = subsample_n / len(df)
    sampled = (
        df.groupby(deciles, observed=True, group_keys=False)
        .apply(lambda g: g.sample(frac=frac, random_state=seed))
        .reset_index(drop=True)
    )
    logger.info(f"Submuestra resultante: {sampled.shape}")
    return sampled


def split_features_target(
    df: pd.DataFrame,
    target_col: str = cfg.TARGET_COL,
    id_col: str = cfg.ID_COL,
) -> tuple[pd.DataFrame, pd.Series, pd.Series]:
    """Separa features, target e ID.

    Args:
        df: DataFrame completo.
        target_col: Nombre del target.
        id_col: Nombre del ID.

    Returns:
        Tupla (X, y, ids).
    """
    cols_drop = [c for c in (target_col, id_col) if c in df.columns]
    X = df.drop(columns=cols_drop)
    y = df[target_col].copy() if target_col in df.columns else None
    ids = df[id_col].copy() if id_col in df.columns else None
    return X, y, ids
