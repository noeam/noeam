"""Preprocesamiento de features y transformaciones del target.

Incluye:
    - Imputación de missings (mediana para numéricas, moda para cats).
    - Conversión de categóricas a dtype ``category`` de pandas para que
      XGBoost las maneje nativamente con ``enable_categorical=True``.
    - Transformaciones invertibles del target (signed-log1p).

La clase Preprocessor se serializa con joblib para reproducibilidad.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal

import joblib
import numpy as np
import pandas as pd

from .utils import setup_logger

logger = setup_logger(__name__)

TargetTransform = Literal["none", "signed_log1p"]


# =============================================================================
# Transformaciones del target (invertibles)
# =============================================================================


def signed_log1p(y: np.ndarray | pd.Series) -> np.ndarray:
    """Aplica ``sign(y) * log1p(|y|)``.

    Preserva el signo y comprime ambas colas. Invertible vía
    ``inverse_signed_log1p``.

    Args:
        y: Array 1-D con el target.

    Returns:
        Array transformado.
    """
    y_arr = np.asarray(y, dtype=np.float64)
    return np.sign(y_arr) * np.log1p(np.abs(y_arr))


def inverse_signed_log1p(y_transformed: np.ndarray | pd.Series) -> np.ndarray:
    """Inversa exacta de :func:`signed_log1p`.

    Args:
        y_transformed: Array transformado.

    Returns:
        Array en la escala original.
    """
    y_arr = np.asarray(y_transformed, dtype=np.float64)
    return np.sign(y_arr) * (np.expm1(np.abs(y_arr)))


def apply_target_transform(
    y: np.ndarray | pd.Series, kind: TargetTransform
) -> np.ndarray:
    """Aplica la transformación indicada.

    Args:
        y: Target sin transformar.
        kind: "none" o "signed_log1p".

    Returns:
        Array transformado (copia).
    """
    if kind == "none":
        return np.asarray(y, dtype=np.float64)
    if kind == "signed_log1p":
        return signed_log1p(y)
    raise ValueError(f"Transformación no soportada: {kind}")


def inverse_target_transform(
    y_transformed: np.ndarray, kind: TargetTransform
) -> np.ndarray:
    """Invierte la transformación indicada."""
    if kind == "none":
        return np.asarray(y_transformed, dtype=np.float64)
    if kind == "signed_log1p":
        return inverse_signed_log1p(y_transformed)
    raise ValueError(f"Transformación no soportada: {kind}")


# =============================================================================
# Preprocessor de features
# =============================================================================


@dataclass
class Preprocessor:
    """Imputa y codifica features de manera reproducible.

    Attributes:
        numeric_cols: Columnas numéricas.
        categorical_cols: Columnas categóricas.
        numeric_medians: Mediana aprendida por columna numérica.
        categorical_modes: Moda aprendida por columna categórica.
        categorical_categories: Niveles observados en train.
    """

    numeric_cols: list[str]
    categorical_cols: list[str]
    numeric_medians: dict[str, float] = field(default_factory=dict)
    categorical_modes: dict[str, object] = field(default_factory=dict)
    categorical_categories: dict[str, list] = field(default_factory=dict)
    _fitted: bool = False

    def fit(self, X: pd.DataFrame) -> "Preprocessor":
        """Aprende estadísticas desde train.

        Args:
            X: DataFrame de train.

        Returns:
            Self (encadenable).
        """
        logger.info("Preprocessor.fit() en curso...")
        for col in self.numeric_cols:
            if col in X.columns:
                self.numeric_medians[col] = float(X[col].median())
        for col in self.categorical_cols:
            if col in X.columns:
                mode_val = X[col].mode(dropna=True)
                self.categorical_modes[col] = (
                    mode_val.iloc[0] if len(mode_val) > 0 else "MISSING"
                )
                # Guardar los niveles (convertidos a str para homogeneidad)
                self.categorical_categories[col] = (
                    X[col].astype(str).fillna("MISSING").unique().tolist()
                )
        self._fitted = True
        logger.info(
            f"  -> medianas: {len(self.numeric_medians)}, "
            f"modas: {len(self.categorical_modes)}"
        )
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        """Aplica imputación y dtypes aprendidos.

        Args:
            X: DataFrame a transformar.

        Returns:
            DataFrame transformado (nueva copia).
        """
        if not self._fitted:
            raise RuntimeError("Preprocessor no ha sido ajustado. Llama fit() primero.")

        X_out = X.copy()

        # Numéricas: imputar con mediana
        for col, median in self.numeric_medians.items():
            if col in X_out.columns:
                X_out[col] = X_out[col].fillna(median).astype(np.float32)

        # Categóricas: imputar con moda + dtype category
        for col, mode in self.categorical_modes.items():
            if col in X_out.columns:
                X_out[col] = X_out[col].astype(str).fillna(str(mode))
                # Fijar el conjunto de categorías al visto en train.
                # Niveles nuevos en test aparecen como NaN, pero al haber
                # imputado con moda antes esto solo ocurre con valores
                # verdaderamente nuevos -> los mapeamos al mode.
                known = self.categorical_categories[col]
                X_out.loc[~X_out[col].isin(known), col] = str(mode)
                X_out[col] = pd.Categorical(X_out[col], categories=known)

        return X_out

    def fit_transform(self, X: pd.DataFrame) -> pd.DataFrame:
        """Equivalente a ``fit`` seguido de ``transform``."""
        return self.fit(X).transform(X)

    def save(self, path: Path) -> None:
        """Serializa el preprocessor con joblib."""
        path.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump(self, path)
        logger.info(f"Preprocessor guardado en {path}")

    @staticmethod
    def load(path: Path) -> "Preprocessor":
        """Carga un preprocessor serializado."""
        return joblib.load(path)
