"""Configuración central del proyecto.

Este módulo centraliza todas las decisiones de diseño del pipeline:
rutas, flags de cómputo, bins de evaluación, parámetros de selección
de variables y rangos de búsqueda para Optuna.

Cambiar cualquier valor aquí se propaga automáticamente a todo el
pipeline (carga, FE, selección, tuning, evaluación).

Attributes:
    USE_GPU: Interruptor único GPU/CPU. Cambiar a False si se pierde
        acceso al servidor Azure.
    TARGET_COL: Nombre de la columna objetivo.
    ID_COL: Nombre de la columna identificador.
    BINS_MILES: Cortes de la matriz de evaluación por rangos, en miles.
    TOP_K_FEATURES: Cuántas variables tomar del ranking por gain para
        feature engineering combinatorial.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np

# =============================================================================
# Rutas
# =============================================================================

ROOT_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT_DIR / "data"
RAW_DIR = DATA_DIR / "raw"
INTERIM_DIR = DATA_DIR / "interim"
PROCESSED_DIR = DATA_DIR / "processed"
MODELS_DIR = ROOT_DIR / "models"
REPORTS_DIR = ROOT_DIR / "reports"
FIGURES_DIR = REPORTS_DIR / "figures"
MLRUNS_DIR = ROOT_DIR / "mlruns"

# Archivos de entrada esperados (CSV en data/raw/)
TRAIN_FILE = RAW_DIR / "train.csv"
TEST_FILE = RAW_DIR / "test.csv"

# =============================================================================
# Columnas del dataset
# =============================================================================

TARGET_COL = "ti_2d"          # ajustar si el nombre real difiere
ID_COL = "id"                 # ajustar si el nombre real difiere

# Columnas categóricas conocidas (≤20 niveles según el usuario).
# Se completan automáticamente si se dejan vacías; si se conocen,
# listarlas aquí reduce tiempo de inferencia de tipos.
CATEGORICAL_COLS: list[str] = []  # p.ej. ["tipo_cliente", "segmento"]

# =============================================================================
# Cómputo
# =============================================================================

USE_GPU = True                 # <-- único switch GPU/CPU
RANDOM_SEED = 42
N_JOBS_CPU = -1                # usado para sklearn/pandas cuando GPU=False

# Device string para XGBoost 2.x
DEVICE = "cuda" if USE_GPU else "cpu"

# Cuando no hay GPU: sub-muestreo opcional para poder correr en laptop.
# None = usar todos los datos. Entero = usar ese # de filas (estratificado).
SUBSAMPLE_ROWS_IF_CPU: int | None = 150_000

# =============================================================================
# Validación
# =============================================================================

N_FOLDS = 5
VAL_SIZE = 0.15                # validación interna para el tuning

# =============================================================================
# Bins de evaluación por rangos (real vs predicho)
# =============================================================================
# Cortes expresados en miles (usuario). Se agregan -inf y +inf para cubrir
# todo el soporte del target (min=-228k, max=378k).

BINS_MILES = [0, 1, 3, 5, 7, 10, 15, 20, 30, 40, 60, 80, 100, 150, 200, 500]

# Construcción de cortes absolutos y labels (se usan en evaluate.py).
BIN_EDGES = np.concatenate(
    [[-np.inf, 0.0], np.array(BINS_MILES[1:]) * 1_000.0, [np.inf]]
)
# Labels de los 17 rangos resultantes.
BIN_LABELS = [
    "<0",
    "0-1k",
    "1k-3k",
    "3k-5k",
    "5k-7k",
    "7k-10k",
    "10k-15k",
    "15k-20k",
    "20k-30k",
    "30k-40k",
    "40k-60k",
    "60k-80k",
    "80k-100k",
    "100k-150k",
    "150k-200k",
    "200k-500k",
    ">500k",
]

# Tolerancias para el porcentaje de acierto en diagonal ± k
DIAGONAL_TOLERANCES = [0, 1, 2, 3]

# =============================================================================
# Definición de "extremos" según el usuario
# =============================================================================
# Percentiles que delimitan los casos extremos relevantes de negocio.
EXTREME_LOWER_Q = 0.02
EXTREME_UPPER_Q = 0.98

# =============================================================================
# Feature engineering
# =============================================================================

TOP_K_FEATURES = 20            # flexible: 20, 30, etc.

# Qué familias de features generar sobre el top-k
FE_FAMILIES = {
    "products": True,          # x_i * x_j
    "ratios": True,            # x_i / x_j (protegido contra div/0)
    "diffs": True,             # x_i - x_j
    "squares": True,           # x_i^2
    "signed_sqrt": True,       # sign(x) * sqrt(|x|)
    "signed_log1p": True,      # sign(x) * log1p(|x|)
}

# Epsilon para proteger divisiones
RATIO_EPS = 1e-6

# =============================================================================
# Loss functions a comparar
# =============================================================================
# Cada entrada define el "experimento" de loss que se corre en MLflow.
# A: Pseudo-Huber sobre target original (robusta natural).
# B: Squared error sobre target transformado con signed-log1p (comprime
#    colas, invertible).

LOSS_CONFIGS = {
    "A_pseudohuber_raw": {
        "xgb_objective": "reg:pseudohubererror",
        "target_transform": "none",
        "description": (
            "Pseudo-Huber sobre el target original. Robusta a outliers "
            "en ambas colas sin transformar y. Controlada por huber_slope."
        ),
    },
    "B_squared_signedlog1p": {
        "xgb_objective": "reg:squarederror",
        "target_transform": "signed_log1p",
        "description": (
            "Squared error sobre y' = sign(y)*log1p(|y|). Comprime colas "
            "preservando signo; invertible en inferencia."
        ),
    },
}

# =============================================================================
# Tuning con Optuna
# =============================================================================

# Presupuesto de tiempo total para tuning (segundos por loss).
TUNING_TIMEOUT_SEC_PER_LOSS = 1_500   # ~25 min por loss en GPU
TUNING_N_TRIALS_MAX = 120             # cap superior

# Pruner agresivo para ahorrar tiempo
PRUNER_STARTUP_TRIALS = 8
PRUNER_WARMUP_STEPS = 15

# Rango de búsqueda para XGBoost (se lee en tune.py)
XGB_PARAM_SPACE = {
    "n_estimators": (300, 2000),
    "max_depth": (4, 10),
    "learning_rate": (0.01, 0.2),
    "min_child_weight": (1, 20),
    "subsample": (0.6, 1.0),
    "colsample_bytree": (0.5, 1.0),
    "colsample_bylevel": (0.5, 1.0),
    "reg_alpha": (1e-8, 10.0),
    "reg_lambda": (1e-8, 10.0),
    "gamma": (1e-8, 5.0),
    # Específico de pseudo-Huber
    "huber_slope": (0.1, 2.0),
}

# =============================================================================
# MLflow
# =============================================================================

MLFLOW_TRACKING_URI = f"file://{MLRUNS_DIR}"
MLFLOW_EXPERIMENT_NAME = "xgb_reg_ti_2d"
