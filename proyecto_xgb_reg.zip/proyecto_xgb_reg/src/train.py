"""Entrenamiento final del modelo con los mejores hiperparámetros.

Re-entrena XGBoost sobre el conjunto completo de training usando los
parámetros ganadores del tuning y aplicando la transformación de target
correspondiente a la loss elegida.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import xgboost as xgb

from . import config as cfg
from .preprocessing import (
    TargetTransform,
    apply_target_transform,
    inverse_target_transform,
)
from .utils import setup_logger

logger = setup_logger(__name__)


def train_final_model(
    X_train: pd.DataFrame,
    y_train: pd.Series,
    best_params: dict[str, Any],
    loss_config_name: str,
    device: str = cfg.DEVICE,
    seed: int = cfg.RANDOM_SEED,
) -> xgb.XGBRegressor:
    """Entrena el modelo final con los mejores hiperparámetros.

    Args:
        X_train: Features de train (completo, ya con FE y preprocess).
        y_train: Target en escala original.
        best_params: Output de :class:`tune.TuningResult.best_params`.
        loss_config_name: Clave en :data:`config.LOSS_CONFIGS`.
        device: "cuda" o "cpu".
        seed: Semilla.

    Returns:
        Modelo XGBRegressor ya ajustado.
    """
    loss_cfg = cfg.LOSS_CONFIGS[loss_config_name]
    objective_str = loss_cfg["xgb_objective"]
    target_transform: TargetTransform = loss_cfg["target_transform"]

    y_tx = apply_target_transform(y_train.to_numpy(), target_transform)

    params = dict(best_params)
    n_estimators = params.pop("n_estimators")

    xgb_params = {
        "objective": objective_str,
        "tree_method": "hist",
        "device": device,
        "enable_categorical": True,
        "eval_metric": "rmse",
        "random_state": seed,
        "verbosity": 0,
        **params,
    }

    logger.info(f"Entrenando modelo final [{loss_config_name}] ...")
    model = xgb.XGBRegressor(n_estimators=n_estimators, **xgb_params)
    model.fit(X_train, y_tx, verbose=False)
    logger.info("  -> modelo final entrenado.")
    return model


def predict_original_scale(
    model: xgb.XGBRegressor,
    X: pd.DataFrame,
    loss_config_name: str,
) -> np.ndarray:
    """Predice e invierte la transformación del target si aplica.

    Args:
        model: Modelo entrenado.
        X: Features.
        loss_config_name: Clave en :data:`config.LOSS_CONFIGS`.

    Returns:
        Predicciones en la escala monetaria original.
    """
    target_transform: TargetTransform = cfg.LOSS_CONFIGS[loss_config_name][
        "target_transform"
    ]
    pred_tx = model.predict(X)
    return inverse_target_transform(pred_tx, target_transform)


def save_model_json(
    model: xgb.XGBRegressor, path: Path, extra_metadata: dict | None = None
) -> None:
    """Serializa el modelo al formato nativo JSON de XGBoost.

    Args:
        model: Modelo entrenado.
        path: Ruta destino (``.json``).
        extra_metadata: Se guarda aparte en ``<path>.meta.json``.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    model.get_booster().save_model(str(path))
    logger.info(f"Modelo guardado en {path}")

    if extra_metadata:
        from .utils import save_json

        save_json(extra_metadata, path.with_suffix(".meta.json"))
